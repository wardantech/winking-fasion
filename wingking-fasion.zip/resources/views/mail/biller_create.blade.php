<h1>Congratulation {{$name}}!</h1>
<h3>Hope that you will be dedicated and honest with your job</h3>
<p>Thank you</p>