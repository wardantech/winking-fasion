@extends('layout.main') @section('content')
@if(session()->has('not_permitted'))
  <div class="alert alert-danger alert-dismissible text-center"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>{{ session()->get('not_permitted') }}</div>
@endif
<section class="forms">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h4>Add Proforma Invoice</h4>
                    </div>
                    <div class="card-body">
                        <p class="italic"><small>{{trans('file.The field labels marked with * are required input fields')}}.</small></p>
                        {!! Form::open(['route' => ['proforma_invoice.update',$lim_invoice_data->id], 'method' => 'put', 'files' => true, 'id' => 'purchase-form']) !!}
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Invoice No *</label>
                                            <input type="text" name="invoice_no" class="form-control" value={{$lim_invoice_data->invoice_no}} required>
                                            @if($errors->has('invoice_no'))
                                                <span class="text-danger">
                                                    {{ $errors->first('invoice_no') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Invoice To *</label>
                                            <select name="invoice_to_id" class="selectpicker form-control" data-live-search="true" data-live-search-style="begins" title="Select invoice to...">
                                                @foreach ($lims_invoice_to_all as $invoice)
                                                    <option value="{{ $invoice->id }}" {{($invoice->id == $lim_invoice_data->invoice_to_id)?'selected':''}}>{{ $invoice->name }}</option>
                                                @endforeach
                                            </select>
                                            @if($errors->has('invoice_to_id'))
                                                <span class="text-danger">
                                                    {{ $errors->first('invoice_to_id') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Inspection Certificate Author *</label>
                                            <input type="text" name="auther" class="form-control" value={{$lim_invoice_data->auther}} required>
                                            @if($errors->has('auther'))
                                                <span class="text-danger">
                                                   {{ $errors->first('auther') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div> --}}
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Customer *</label>
                                            <select name="customer_id" required class="selectpicker form-control" data-live-search="true" data-live-search-style="begins" title="Select customer ...">
                                                @foreach ($lims_customer_all as $customer)
                                                    <option value="{{ $customer->id }}" {{ ($lim_invoice_data->customer_id == $customer->id)?'selected':'' }}>{{ $customer->name }}</option>
                                                @endforeach
                                            </select>
                                            @if($errors->has('customer_id'))
                                                <span class="text-danger">
                                                   {{ $errors->first('customer_id') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>

                                    {{-- <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Application Bank Details</label>
                                            <textarea name="applicant_bank" class="form-control" id="applicant_bank">{!! $lim_invoice_data->applicant_bank !!}</textarea>
                                            @if($errors->has('applicant_bank'))
                                                <span class="text-danger">
                                                   {{ $errors->first('applicant_bank') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Vendor Bank Details</label>
                                            <textarea name="vendor_bank" class="form-control" id="vendor_bank">{!! $lim_invoice_data->vendor_bank !!}</textarea>
                                            @if($errors->has('vendor_bank'))
                                                <span class="text-danger">
                                                   {{ $errors->first('vendor_bank') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div> --}}
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Season</label>
                                            <input type="text" name="season" class="form-control" value={{$lim_invoice_data->season}} required>
                                            @if($errors->has('season'))
                                                <span class="text-danger">
                                                   {{ $errors->first('season') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Delivery Date *</label>
                                            <input type="date" name="delivery_date" class="form-control" value={{$lim_invoice_data->delivery_date}} required>
                                            @if($errors->has('delivery_date'))
                                                <span class="text-danger">
                                                   {{ $errors->first('delivery_date') }}
                                                </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Total Quantity *</label>
                                            <input type="text" name="total_qty" id="total_qty" class="form-control total_qty" value={{$lim_invoice_data->total_qty}}>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Total Amount *</label>
                                            <input type="text" name="total_amount" id="total_amount" class="form-control total_amount" value={{$lim_invoice_data->total_amount}}>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Upload New Proforma Invoice *</label>
                                            <input type="file" name="document" class="form-control"/>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Old Document</label>
                                            <p style="color: red;">{{$lim_invoice_data->document}}</p>
                                        </div>
                                    </div>
                                </div>


                            {{-- <div class="break_down">
                                    <label>DESCRIPTION OF THE MERCHANDISES</label>
                            </div> --}}


                            {{-- <div class="description" style="margin: 10px 0px;">
                                <div class="row">
                                    <div class="col-md-12" id="dynamicSection">
                                        <div id="description" style="margin:20px 0px;">
                                            <table width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>PO*</th>
                                                        <th>Style</th>
                                                        <th>Item Description</th>
                                                        <th>Wash/Color</th>
                                                        <th>Order Qty*</th>
                                                        <th>Unit Price*</th>
                                                        <th>Total Value</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="table_body">
                                                    @php
                                                        $merchandies = unserialize($lim_invoice_data->merchandies);
                                                    @endphp
                                                    @foreach ($merchandies as $key=>$item)
                                                        <tr>
                                                            <td width="12%"><input type="text" name="po[]" value={{$item['po']}} class="form-control" required></td>
                                                            <td width="13%"><input type="text" name="style[]" value={{$item['style']}} class="form-control"></td>
                                                            <td width="30%"><input type="text" name="item_description[]" value={{$item['item_description']}} class="form-control"></td>
                                                            <td width="10%"><input type="text" name="color[]" value={{$item['color']}} class="form-control"></td>
                                                            <td width="10%"><input type="number" name="quantity[]" value={{$item['quantity']}} id="quantity" min="0" step="any" class="form-control quantity" required></td>
                                                            <td width="12%"><input type="number" name="unit_price[]" value={{$item['unit_price']}} id="unit_price" min="0" step="0.01" class="form-control unit_price" required></td>
                                                            <td width="12%"><input type="text" name="total_value[]" value={{$item['total_value']}} id="total_value" class="form-control total_value" readonly required></td>
                                                            <td>
                                                                @if ($key == 0)
                                                                   <a id="add_description" class="btn btn-danger btn-sm" style="color:white;margin-left:10px;">+</a>
                                                                @else
                                                                   <a id="remove" class="btn btn-danger btn-sm" style="color:white;margin-left:10px;">-</a>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Total Quantity</label>
                                            <input type="text" name="total_qty" id="total_qty" class="form-control total_qty" value={{$lim_invoice_data->total_qty}} readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Total Amount</label>
                                            <input type="text" name="total_amount" id="total_amount" class="form-control total_amount" value={{$lim_invoice_data->total_amount}} readonly>
                                        </div>
                                    </div>
                                </div>
                            </div> --}}

                                {{-- <div class="break_down">
                                    <label>TERMS AND CONDITION</label>
                                </div> --}}

                                {{-- <div class="row">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Payment Terms</label>
                                                    <input type="text" name="payment_terms" class="form-control" value={{$lim_invoice_data->payment_terms}} required>
                                                    @if($errors->has('payment_terms'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('payment_terms') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>LC Terms</label>
                                                    <input type="text" name="lc_terms" class="form-control" value={{$lim_invoice_data->lc_terms}} required>
                                                    @if($errors->has('lc_terms'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('lc_terms') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Date of expire *</label>
                                                    <input type="date" name="expire_date" class="form-control" value={{$lim_invoice_data->expire_date}} required>
                                                    @if($errors->has('expire_date'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('expire_date') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Shipment date *</label>
                                                    <input type="date" name="shipment_date" class="form-control" value={{$lim_invoice_data->shipment_date}} required>
                                                    @if($errors->has('shipment_date'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('shipment_date') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Port of loading *</label>
                                                    <select name="port_of_loading" class="form-control" data-live-search="true" data-live-search-style="begins" title="Select port of loading ..." required>
                                                         <option value="Chittagong, Bangladesh" {{($lim_invoice_data->port_of_loading == 'Chittagong, Bangladesh')?'selected':''}}>Chittagong, Bangladesh</option>
                                                         <option value="Dhaka, Bangladesh" {{($lim_invoice_data->port_of_loading == 'Dhaka, Bangladesh')?'selected':''}}>Dhaka, Bangladesh</option>
                                                    </select>
                                                    @if($errors->has('port_of_loading'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('port_of_loading') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Port of destination *</label>
                                                    <input type="text" name="port_of_destination" class="form-control" value={{$lim_invoice_data->port_of_destination}} required>
                                                    @if($errors->has('port_of_loading'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('port_of_loading') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Mode of shipment *</label>
                                                    <select name="mode_of_shipment" class="form-control" data-live-search="true" data-live-search-style="begins" title="Select port of loading ..." required>
                                                         <option value="Sea" {{($lim_invoice_data->mode_of_shipment == 'Sea')?'selected':''}}>Sea</option>
                                                         <option value="Air" {{($lim_invoice_data->mode_of_shipment == 'Air')?'selected':''}}>Air</option>
                                                    </select>
                                                    @if($errors->has('mode_of_shipment'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('mode_of_shipment') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Transshipment *</label>
                                                    <select name="transshipment" class="form-control" data-live-search="true" data-live-search-style="begins" title="Select port of loading ..." required>
                                                         <option value="Allowed" {{($lim_invoice_data->transshipment == 'Allowed')?'selected':''}}>Allowed</option>
                                                         <option value="Not Allowed" {{($lim_invoice_data->transshipment == 'Not Allowed')?'selected':''}}>Not Allowed</option>
                                                    </select>
                                                    @if($errors->has('transshipment'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('transshipment') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Amount & Quantity Acceptable (%) *</label>
                                                    <input type="number" name="acceptable_amount" class="form-control" value={{$lim_invoice_data->acceptable_amount}} required>
                                                    @if($errors->has('transshipment'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('transshipment') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Partial Shipment *</label>
                                                    <select name="partial_shipment" class="form-control" data-live-search="true" data-live-search-style="begins" title="Select port of loading ..." required>
                                                         <option value="Allowed" {{($lim_invoice_data->partial_shipment == 'Allowed')?'selected':''}}>Allowed</option>
                                                         <option value="Not Allowed" {{($lim_invoice_data->partial_shipment == 'Not Allowed')?'selected':''}}>Not Allowed</option>
                                                    </select>
                                                    @if($errors->has('partial_shipment'))
                                                        <span class="text-danger">
                                                           {{ $errors->first('partial_shipment') }}
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12" id="dynamicSection">
                                                <div id="description" style="margin:20px 0px;">
                                                    @php
                                                        $instructions = unserialize($lim_invoice_data->instruction);
                                                    @endphp
                                                    <table width="100%">
                                                        <thead>
                                                            <tr>
                                                                <th>More Instructions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="table_body2">
                                                        @foreach ($instructions as $key=>$instruction)
                                                            <tr>
                                                                <td width="98%"><input type="text" name="instruction[]" value="{{$instruction}}" class="form-control"></td>
                                                                <td>
                                                                    @if ($key == 0)
                                                                        <a id="add_instruction" class="btn btn-danger btn-sm" style="color:white;margin-left:10px;">+</a>
                                                                    @else
                                                                         <a id="remove_ins" class="btn btn-danger btn-sm" style="color:white;margin-left:10px;">-</a>
                                                                    @endif
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> --}}

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" id="submit-btn">{{trans('file.submit')}}</button>
                            </div>
                            </div>
                        </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">

    $("ul#order-summary").siblings('a').attr('aria-expanded','true');
    $("ul#order-summary").addClass("show");
    $("ul#order-summary #proforma-invoice-menu").addClass("active");


    $(document).ready(function(){
        var max_field = 5;
        var wrapper = $("#table_body2");
        var x = 1;
        $("#add_instruction").click(function(){
            if(x < max_field){
                x++;
                $(wrapper).append('<tr>\
                            <td width="98%"><input type="text" name="instruction[]" class="form-control"></td>\
                            <td><a id="remove_ins" class="btn btn-danger btn-sm" style="color:white;margin-left:10px;">-</a></td>\
                        </tr>');
            }else{
                alert('you can not add more than 5 field');
            }
        });
        $(document).on('click', '#remove_ins', function(){
             $(this).parents('tr').remove();
        });
    });
    $(document).ready(function(){
        var max_field = 20;
        var wrapper = $("#table_body");
        var x = 1;
        $("#add_description").click(function(){
            if(x < max_field){
                x++;
                $(wrapper).append('<tr>\
                            <td width="12%"><input type="text" name="po[]" class="form-control" required></td>\
                            <td width="13%"><input type="text" name="style[]" class="form-control"></td>\
                            <td width="30%"><input type="text" name="item_description[]" class="form-control"></td>\
                            <td width="10%"><input type="text" name="color[]" class="form-control"></td>\
                            <td width="10%"><input type="number" name="quantity[]" id="quantity" min="0" step="any" class="form-control quantity" required></td>\
                            <td width="12%"><input type="number" name="unit_price[]" id="unit_price" min="0" step="0.01" class="form-control unit_price" required></td>\
                            <td width="12%"><input type="text" name="total_value[]" id="total_value" class="form-control total_value" readonly required></td>\
                            <td><a id="remove" class="btn btn-danger btn-sm" style="color:white;margin-left:10px;">-</a></td>\
                        </tr>');
            }else{
                alert('you can not add more than 20 field');
            }
        });

        $(document).on('click', '#remove', function(){
             $(this).parents('tr').remove();
                var sum = 0;
                var totqty = 0;
                var sum_client = 0;
                $(".total_value").each(function(){
                    sum += +$(this).val();
                });
                $(".quantity").each(function(){
                    totqty += +$(this).val();
                });
                $("#total_qty").val(totqty);
                $("#total_amount").val(parseFloat(sum).toFixed(2));
        });
    });
$(document).ready(function () {

    $(document).on('keyup change', '#quantity, #unit_price', function() {

        var quantity = $(this).closest('tr').find('.quantity').val();
        var unit_price = $(this).closest('tr').find('.unit_price').val();
        var subtotal = parseFloat(quantity * unit_price).toFixed(2);

        $(this).closest('tr').find('.total_value').val(subtotal);

    });


    $(document).on("change keyup", "#unit_price , #quantity", function() {
        var sum = 0;
        var totqty = 0;
        $(".total_value").each(function(){
            sum += +$(this).val();
        });
        $(".quantity").each(function(){
            totqty += +$(this).val();
        });
        $("#total_qty").val(totqty);
        $("#total_amount").val(parseFloat(sum).toFixed(2));
        //$(".total").val(sum);
    });


});

tinymce.init({
    selector: 'textarea',
    height: 130,
    plugins: [
    'advlist autolink lists link image charmap print preview anchor textcolor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table contextmenu paste code wordcount'
    ],
    toolbar: 'insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat',
    branding:false
});
</script>
@endsection
